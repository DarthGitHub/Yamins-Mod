using Terraria.ModLoader;

namespace YaxilMod
{
	class YaxilMod : Mod
	{
		public YaxilMod()
		{
		}
	}
}
